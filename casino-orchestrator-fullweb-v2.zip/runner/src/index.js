import { chromium } from 'playwright';

function normSelector(s){
  if (!s) return s;
  // Allow 'xpath=...' engine
  if (s.startsWith('xpath=')) return s;
  // Convert 'css=' to bare CSS
  if (s.startsWith('css=')) return s.slice(4);
  return s;
}

async function main(){
  const spec = JSON.parse(Buffer.from(process.env.RUN_SPEC || '', 'base64').toString('utf8'));
  const { provider, casinoId, flowName, countryCode, baseUrl, selectors={}, gameUrl='', creds={}, flow } = spec;

  const defaults = {
    username:'#username', password:'#password', loginBtn:'button[type=submit]',
    postLoginGuard:'header, nav, .dashboard, [data-test=dashboard]',
    aviatorLink:'a:has-text("Aviator")', gameRoot:'#aviator-root',
    betInput:'input[name=betAmount]', placeBetBtn:'button:has-text("Place Bet")',
    successToast:'.toast-success, [role=status]', balance:'.balance, .balance-amount'
  };
  const sel = { ...defaults, ...(selectors||{}) };

  // adopt flow if provided; else fallback to minimal
  const steps = Array.isArray(flow?.steps) && flow.steps.length ? flow.steps : [
    { action:'goto', url: `${baseUrl}/login` },
    { action:'fill', selector: sel.username, value: creds.user||'' },
    { action:'fill', selector: sel.password, value: creds.pass||'' },
    { action:'click', selector: sel.loginBtn },
    { action:'wait_visible', selector: sel.postLoginGuard, timeout:20000 }
  ];

  const browser = await chromium.launch({ headless:true, args:['--no-sandbox','--disable-dev-shm-usage'] });
  const context = await browser.newContext({ locale:'en-US', timezoneId:'UTC' });
  const page = await context.newPage();

  let scope = page;
  let consoleErrs = 0;
  page.on('console', m => { if (m.type()==='error') consoleErrs++; });

  const t0 = Date.now();
  let ok = true, message = 'ok', balPresent = 0;

  try {
    for (const st of steps){
      const t = st.timeout || (flow?.timeouts?.default ?? 10000);
      const action = st.action;

      if (action === 'goto'){
        const url = st.url.replace('{{baseUrl}}', baseUrl);
        await page.goto(url, { waitUntil:'domcontentloaded', timeout:t });
        scope = page;
      } else if (action === 'select_frame'){
        if (typeof st.index === 'number'){
          const frames = page.frames();
          const f = frames[st.index];
          if (!f) throw new Error('frame index not found: '+st.index);
          scope = f;
        } else if (st.selector){
          const h = await page.$(normSelector(st.selector));
          if (!h) throw new Error('frame el not found: '+st.selector);
          const f = await h.contentFrame();
          if (!f) throw new Error('no contentFrame for '+st.selector);
          scope = f;
        }
      } else if (action === 'click'){
        await scope.locator(normSelector(st.selector)).click({ timeout:t });
      } else if (action === 'hover'){
        await scope.locator(normSelector(st.selector)).hover({ timeout:t });
      } else if (action === 'fill'){
        let v = st.value ?? '';
        if (st.secret === 'casino_user') v = creds.user || '';
        if (st.secret === 'casino_pass') v = creds.pass || '';
        await scope.locator(normSelector(st.selector)).fill(v, { timeout:t });
      } else if (action === 'wait_visible'){
        await scope.locator(normSelector(st.selector)).first().waitFor({ state:'visible', timeout:t });
      } else if (action === 'expect_text'){
        const loc = scope.locator(normSelector(st.selector)).first();
        await loc.waitFor({ state:'visible', timeout:t });
        const tx = await loc.innerText({ timeout:t });
        if (!tx || (st.text && !tx.includes(st.text))) throw new Error('expect_text failed');
      }
    }

    // balance best-effort
    try {
      const tx = await page.locator(normSelector(sel.balance)).first().innerText({ timeout: 8000 });
      const m = tx && tx.match(/[0-9]+(?:[.,][0-9]+)?/);
      const bal = m ? parseFloat(m[0].replace(',','.')) : NaN;
      balPresent = Number(Number.isFinite(bal) && bal>0);
    } catch {}

  } catch (e){
    ok = false; message = e?.message || 'failed';
  } finally {
    const dur = (Date.now()-t0)/1000;
    const result = { ok, message, duration: dur, consoleErrors: consoleErrs, balancePresent: balPresent };
    console.log('RESULT_JSON:' + Buffer.from(JSON.stringify(result)).toString('base64'));
    await context.close(); await browser.close();
  }
}

main().catch(e=>{
  const out = Buffer.from(JSON.stringify({ ok:false, message:e?.message||'crash', duration:0, consoleErrors:0, balancePresent:0 })).toString('base64');
  console.log('RESULT_JSON:'+out);
});
