import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import fs from 'node:fs/promises';
import fss from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import Docker from 'dockerode';
import client from 'prom-client';
import { CronJob } from 'cron';
import multer from 'multer';

const app = express();
app.use(cors());
app.use(express.json({ limit:'15mb' }));
app.use(express.static(path.join(process.cwd(), 'public')));

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const MASTER_KEY = process.env.MASTER_KEY || '';
const PROTON_USER = process.env.PROTON_USER || '';
const PROTON_PASS = process.env.PROTON_PASS || '';
const PROTONVPN_IMAGE = process.env.PROTONVPN_IMAGE || 'ghcr.io/qdm12/gluetun:latest';
const RUNNER_IMAGE = process.env.RUNNER_IMAGE || 'casino-runner:latest';

const DB_DIR = path.join(process.cwd(), 'db');
const USERS_FILE = path.join(DB_DIR, 'users.json');
const PROVIDERS_FILE = path.join(process.cwd(), 'data/providers.json');
const CASINOS_FILE = path.join(process.cwd(), 'data/casinos.json');
const COUNTRIES_FILE = path.join(process.cwd(), 'data/countries.json');
const FLOWS_DIR = path.join(process.cwd(), 'flows');
const SECRETS_FILE = path.join(DB_DIR, 'secrets.json');
const SCHEDULES_FILE = path.join(DB_DIR, 'schedules.json');

if (!fss.existsSync(DB_DIR)) fss.mkdirSync(DB_DIR, { recursive: true });
if (!fss.existsSync(USERS_FILE)) {
  const def = [
    { username: 'admin', role: 'admin', passhash: bcrypt.hashSync('admin123', 8) },
    { username: 'viewer', role: 'viewer', passhash: bcrypt.hashSync('viewer123', 8) }
  ];
  fss.writeFileSync(USERS_FILE, JSON.stringify(def, null, 2));
}
if (!fss.existsSync(SECRETS_FILE)) fss.writeFileSync(SECRETS_FILE, JSON.stringify({}, null, 2));
if (!fss.existsSync(SCHEDULES_FILE)) fss.writeFileSync(SCHEDULES_FILE, JSON.stringify([], null, 2));
if (!fss.existsSync(COUNTRIES_FILE)) {
  const def = { "Germany":"DE","Sweden":"SE","Norway":"NO","Hungary":"HU","India":"IN","Nigeria":"NG","Poland":"PL","Italy":"IT","Spain":"ES","Georgia":"GE" };
  fss.writeFileSync(COUNTRIES_FILE, JSON.stringify(def, null, 2));
}
if (!fss.existsSync(FLOWS_DIR)) fss.mkdirSync(FLOWS_DIR, { recursive: true });
if (!fss.existsSync(PROVIDERS_FILE)) fss.writeFileSync(PROVIDERS_FILE, JSON.stringify({ Gamekong: [] }, null, 2));
if (!fss.existsSync(path.join(process.cwd(), 'data'))) fss.mkdirSync(path.join(process.cwd(), 'data'), { recursive: true });
if (!fss.existsSync(CASINOS_FILE)) fss.writeFileSync(CASINOS_FILE, JSON.stringify([], null, 2));

const docker = new Docker({ socketPath: '/var/run/docker.sock' });

// Prometheus metrics
const register = new client.Registry();
client.collectDefaultMetrics({ register });
const runStatus = new client.Counter({ name:'run_status_total', help:'Run status', labelNames:['provider','casino','country','flow','status'] });
const runDuration = new client.Histogram({ name:'run_duration_seconds', help:'Duration', labelNames:['provider','casino','country','flow'], buckets:[1,3,5,10,20,30,60,120] });
const consoleErrors = new client.Counter({ name:'console_errors_total', help:'Console errors', labelNames:['provider','casino','country','flow'] });
const balancePresent = new client.Counter({ name:'balance_present_total', help:'Balance present flag', labelNames:['provider','casino','country','flow'] });
register.registerMetric(runStatus); register.registerMetric(runDuration); register.registerMetric(consoleErrors); register.registerMetric(balancePresent);

app.get('/metrics', async (req,res)=>{ res.set('Content-Type', register.contentType); res.end(await register.metrics()); });

// crypto helpers
function encrypt(text){ if (!MASTER_KEY) return text; const key=Buffer.from(MASTER_KEY,'hex'); const iv=crypto.randomBytes(16); const cipher=crypto.createCipheriv('aes-256-gcm', key, iv); const enc=Buffer.concat([cipher.update(text,'utf8'),cipher.final()]); const tag=cipher.getAuthTag(); return Buffer.concat([Buffer.from('01','hex'), iv, tag, enc]).toString('base64'); }
function decrypt(b64){ if (!MASTER_KEY) return b64; try{ const raw=Buffer.from(b64,'base64'); const iv=raw.slice(1,17), tag=raw.slice(17,33), data=raw.slice(33); const key=Buffer.from(MASTER_KEY,'hex'); const decipher=crypto.createDecipheriv('aes-256-gcm', key, iv); decipher.setAuthTag(tag); const dec=Buffer.concat([decipher.update(data), decipher.final()]); return dec.toString('utf8'); } catch{ return ''; } }

// auth middleware
function auth(req,res,next){ const hdr=req.headers.authorization||''; const token=hdr.startsWith('Bearer ')?hdr.slice(7):''; if(!token) return res.status(401).json({error:'no token'}); try{ req.user=jwt.verify(token, JWT_SECRET); next(); } catch{ return res.status(401).json({error:'bad token'});} }
function only(role){ return (req,res,next)=> req.user?.role===role ? next() : res.status(403).json({error:'forbidden'}); }

// file helpers
async function loadJSON(file){ return JSON.parse(await fs.readFile(file,'utf8')); }
async function saveJSON(file, obj){ await fs.writeFile(file, JSON.stringify(obj, null, 2)); }

// Docker helpers
async function ensureImage(image){
  const images = await docker.listImages();
  const has = images.some(img =>
    (img.RepoTags||[]).includes(image) ||
    (img.RepoDigests||[]).some(d => d.includes(image.split(':')[0]))
  );
  if (!has) {
    await new Promise((resolve, reject) => {
      docker.pull(image, (err, stream) => {
        if (err) return reject(err);
        docker.modem.followProgress(stream, (err2) => err2 ? reject(err2) : resolve());
      });
    });
  }
}

async function ensureVpn(countryCode){
  await ensureImage(PROTONVPN_IMAGE);
  const name = `vpn-${countryCode}`;
  const list = await docker.listContainers({ all:true });
  const found = list.find(c => c.Names.includes('/'+name));
  let cont = found ? docker.getContainer(found.Id) : null;
  if (!found) {
    cont = await docker.createContainer({
      name,
      Image: PROTONVPN_IMAGE,
      Env: [
        'VPN_SERVICE_PROVIDER=protonvpn',
        `OPENVPN_USER=${PROTON_USER}`,
        `OPENVPN_PASSWORD=${PROTON_PASS}`,
        `SERVER_COUNTRIES=${countryCode}`,
        `TZ=${process.env.TZ||'UTC'}`
      ],
      HostConfig: {
        CapAdd: ['NET_ADMIN'],
        Devices: [{ PathOnHost:'/dev/net/tun', PathInContainer:'/dev/net/tun', CgroupPermissions:'rwm' }],
        RestartPolicy: { Name: 'unless-stopped' }
      }
    });
  }
  const insp = await cont.inspect();
  if (!insp.State.Running) await cont.start();
  // quick warm-up wait (max 12s)
  const start = Date.now();
  while (Date.now()-start < 12000) { await new Promise(r=>setTimeout(r,500)); break; }
  return name;
}

async function runRunner(countryCode, spec){
  await ensureImage(RUNNER_IMAGE);
  const name = `runner-${spec.casinoId}-${Date.now()}`;
  const cont = await docker.createContainer({
    name,
    Image: RUNNER_IMAGE,
    Env: [ `RUN_SPEC=${Buffer.from(JSON.stringify(spec)).toString('base64')}` ],
    HostConfig: {
      NetworkMode: `container:vpn-${countryCode}`,
      ShmSize: 1024*1024*1024,
      Tmpfs: { "/tmp": "size=512m" }
    }
  });
  await cont.start();
  const status = await cont.wait();
  const logs = await cont.logs({ stdout:true, stderr:true, tail:10000 });
  await cont.remove({ force:true });
  const logStr = logs.toString('utf8');
  let result = { ok:false, message:'no result', duration:0, consoleErrors:0, balancePresent:0 };
  const m = logStr.match(/RESULT_JSON:(.+)/);
  if (m) { try { result = JSON.parse(Buffer.from(m[1].trim(),'base64').toString('utf8')); } catch {} }
  return { result, rawLogs: logStr };
}

// auth routes
app.post('/api/login', async (req,res)=>{
  const { username, password } = req.body || {};
  const users = await loadJSON(USERS_FILE);
  const u = users.find(x=>x.username===username);
  if (!u) return res.status(401).json({ error:'invalid' });
  if (!bcrypt.compareSync(password, u.passhash)) return res.status(401).json({ error:'invalid' });
  const token = jwt.sign({ username:u.username, role:u.role }, JWT_SECRET, { expiresIn:'12h' });
  res.json({ token, user:{ username:u.username, role:u.role } });
});
app.get('/api/me', auth, (req,res)=> res.json({ username:req.user.username, role:req.user.role }));

// providers
app.get('/api/providers', auth, async (req,res)=>{ const p=await loadJSON(PROVIDERS_FILE); res.json(Object.keys(p)); });
app.post('/api/provider', auth, only('admin'), async (req,res)=>{
  const { name } = req.body || {}; if (!name) return res.status(400).json({ error:'name required' });
  const providers = await loadJSON(PROVIDERS_FILE); if (!providers[name]) providers[name]=[];
  await saveJSON(PROVIDERS_FILE, providers); res.json({ ok:true, providers:Object.keys(providers) });
});

// casinos
app.get('/api/casinos', auth, async (req,res)=>{
  const providers = await loadJSON(PROVIDERS_FILE);
  const casinos = await loadJSON(CASINOS_FILE);
  if (req.query.all) return res.json(casinos);
  const provider = req.query.provider || Object.keys(providers)[0];
  const ids = providers[provider] || [];
  res.json(ids.map(id => casinos.find(c=>c.id===id)).filter(Boolean));
});
app.get('/api/casino/:id', auth, async (req,res)=>{
  const casinos = await loadJSON(CASINOS_FILE);
  const c = casinos.find(x=>x.id===req.params.id);
  if (!c) return res.status(404).json({ error:'not found' });
  res.json(c);
});
app.post('/api/casino', auth, only('admin'), async (req,res)=>{
  const c = req.body || {};
  if (!c.id || !c.name || !c.baseUrl) return res.status(400).send('id, name, baseUrl required');
  const casinos = await loadJSON(CASINOS_FILE);
  const i = casinos.findIndex(x=>x.id===c.id);
  if (i>=0) casinos[i] = { ...casinos[i], ...c }; else casinos.push(c);
  await saveJSON(CASINOS_FILE, casinos);
  const providers = await loadJSON(PROVIDERS_FILE);
  const p = c.provider || 'Default'; if (!providers[p]) providers[p]=[];
  if (!providers[p].includes(c.id)) providers[p].push(c.id);
  await saveJSON(PROVIDERS_FILE, providers);
  res.send('saved');
});
app.delete('/api/casino/:id', auth, only('admin'), async (req,res)=>{
  const id = req.params.id;
  const casinos = await loadJSON(CASINOS_FILE);
  await saveJSON(CASINOS_FILE, casinos.filter(c=>c.id!==id));
  const providers = await loadJSON(PROVIDERS_FILE);
  for (const k of Object.keys(providers)) providers[k] = providers[k].filter(x=>x!==id);
  await saveJSON(PROVIDERS_FILE, providers);
  res.send('deleted');
});
app.post('/api/secret', auth, only('admin'), async (req,res)=>{
  const { id, user, pass } = req.body || {};
  if (!id || !user || !pass) return res.status(400).send('id, user, pass required');
  const secrets = await loadJSON(SECRETS_FILE);
  secrets[id.toUpperCase()] = { user: encrypt(user), pass: encrypt(pass) };
  await saveJSON(SECRETS_FILE, secrets);
  res.send('credentials saved');
});

// countries
app.get('/api/countries', auth, async (req,res)=> res.json(await loadJSON(COUNTRIES_FILE)));
app.post('/api/country', auth, only('admin'), async (req,res)=>{
  const { label, code } = req.body || {};
  if (!label || !code) return res.status(400).send('label, code required');
  const countries = await loadJSON(COUNTRIES_FILE);
  countries[label] = code.toUpperCase(); await saveJSON(COUNTRIES_FILE, countries);
  res.send('country saved');
});

// flows
app.get('/api/flows', auth, async (req,res)=>{
  const list = fss.readdirSync(FLOWS_DIR).filter(f=>f.endsWith('.json')).map(f=>f.replace(/\.json$/,''));
  // stable order: synthetic first
  const synthetic = list.filter(n => /synthetic/i.test(n));
  const rest = list.filter(n => !/synthetic/i.test(n));
  res.json([...synthetic.sort(), ...rest.sort()]);
});

// Selenium import
const upload = multer({ storage: multer.memoryStorage() });

function normalizeTarget(t){
  if (!t) return '';
  if (Array.isArray(t)) return t[0][0] || '';
  return t;
}
function mapSeleniumToFlow(side, opts={ mapSecrets:true }){
  const out = { name: side.name || 'imported_flow', steps: [], timeouts:{ default: 10000 } };
  const tests = Array.isArray(side.tests) ? side.tests : [];
  const cmds = tests[0]?.commands || [];
  for (const c of cmds){
    const cmd = c.command;
    const target = normalizeTarget(c.targets && c.targets.length ? c.targets : c.target);
    const val = c.value || '';

    if (cmd === 'open'){
      const path = target.startsWith('/') ? target : ('/' + target);
      out.steps.push({ action:'goto', url:`{{baseUrl}}${path}` });
    } else if (cmd === 'click'){
      out.steps.push({ action:'click', selector: target });
    } else if (cmd === 'type'){
      const isUser = /user|email|login/i.test(target);
      const isPass = /pass/i.test(target);
      out.steps.push({
        action:'fill',
        selector: target,
        ...(opts.mapSecrets && isUser ? { secret:'casino_user' } :
           opts.mapSecrets && isPass ? { secret:'casino_pass' } :
           { value: val })
      });
    } else if (cmd === 'mouseOver'){
      out.steps.push({ action:'hover', selector: target });
    } else if (cmd === 'selectFrame'){
      if (/^index=\d+/.test(c.target)) {
        const idx = Number(c.target.split('=')[1]);
        out.steps.push({ action:'select_frame', index: idx });
      } else {
        out.steps.push({ action:'select_frame', selector: target });
      }
    } else {
      if (target) out.steps.push({ action:'wait_visible', selector: target, timeout: 15000 });
    }
  }
  return out;
}

app.post('/api/selenium_import_file', auth, only('admin'), upload.single('file'), async (req,res)=>{
  try {
    const flowName = req.body?.flowName;
    const mapSecrets = req.body?.mapSecrets === '1';
    if (!flowName || !req.file) return res.status(400).json({ error:'flowName and file required' });
    const json = JSON.parse(req.file.buffer.toString('utf8'));
    const flow = mapSeleniumToFlow(json, { mapSecrets }); flow.name = flowName;
    await fs.writeFile(path.join(FLOWS_DIR, flowName + '.json'), JSON.stringify(flow, null, 2));
    res.json({ ok:true, flowName, steps: flow.steps.length });
  } catch (e) { res.status(500).json({ error: e?.message || 'failed to import' }); }
});

// helpers
async function getFlow(flowName){ const p=path.join(FLOWS_DIR, flowName + '.json'); return JSON.parse(await fs.readFile(p,'utf8')); }
async function getCasinoSpec(casinoId){
  const casinos = await loadJSON(CASINOS_FILE);
  const secrets = await loadJSON(SECRETS_FILE);
  const c = casinos.find(x=>x.id===casinoId); if (!c) throw new Error('casino not found: '+casinoId);
  const rec = secrets[casinoId.toUpperCase()] || {};
  const creds = { user: decrypt(rec.user||'') || '', pass: decrypt(rec.pass||'') || '' };
  return { casino:c, creds };
}

// promise pool for concurrency
async function pool(items, limit, iterate){
  const ret = []; let i=0; const exec = async () => {
    while (i < items.length){
      const idx = i++; const res = await iterate(items[idx], idx); ret[idx] = res;
    }
  };
  const workers = Array(Math.min(limit, items.length)).fill(0).map(()=>exec());
  await Promise.all(workers); return ret;
}

// run
app.post('/api/run', auth, async (req,res)=>{
  const { provider, casinoId, casinoIds=[], country, flowName='bet_smoke', schedule=false, runAll=false, parallel=2 } = req.body || {};
  const countries = await loadJSON(COUNTRIES_FILE);
  const code = (country||'').toUpperCase();
  if (!Object.values(countries).includes(code)) return res.status(400).json({ error:'unknown country' });

  if (schedule){
    const schedules = await loadJSON(SCHEDULES_FILE);
    const providers = await loadJSON(PROVIDERS_FILE);
    const targets = [];
    if (runAll){
      for (const cid of (providers[provider] || [])) targets.push({ provider, casinoId: cid, country: code, flowName });
    } else if (casinoIds?.length) {
      for (const cid of casinoIds) targets.push({ provider, casinoId: cid, country: code, flowName });
    } else {
      targets.push({ provider, casinoId, country: code, flowName });
    }
    const crons = ['0 9 * * *','0 15 * * *','0 2 * * *'];
    for (const t of targets) for (const cron of crons) schedules.push({ ...t, cron });
    await saveJSON(SCHEDULES_FILE, schedules);
    return res.json({ ok:true, scheduled:true, count: targets.length * 3 });
  }

  // immediate run
  const providers = await loadJSON(PROVIDERS_FILE);
  const targets = [];
  if (runAll){
    for (const cid of (providers[provider] || [])) targets.push({ provider, casinoId: cid, country: code, flowName });
  } else if (casinoIds?.length){
    for (const cid of casinoIds) targets.push({ provider, casinoId: cid, country: code, flowName });
  } else {
    targets.push({ provider, casinoId, country: code, flowName });
  }

  // ensure VPN once
  await ensureVpn(code);

  const results = await pool(targets, Math.max(1, Math.min(6, Number(parallel)||1)), async (t) => {
    try {
      const { casino, creds } = await getCasinoSpec(t.casinoId);
      const flow = await getFlow(t.flowName);
      const spec = { provider:t.provider, casinoId:t.casinoId, flowName:t.flowName, countryCode:t.country, baseUrl:casino.baseUrl, selectors:casino.selectors||{}, gameUrl:casino.gameUrl||'', flow, creds };
      const start = Date.now();
      const { result } = await runRunner(t.country, spec);
      const dur = (Date.now()-start)/1000;
      const labels = { provider:t.provider, casino:t.casinoId, country:t.country, flow:t.flowName };
      runDuration.labels(labels).observe(dur);
      consoleErrors.labels(labels).inc(result.consoleErrors||0);
      balancePresent.labels(labels).inc(result.balancePresent?1:0);
      runStatus.labels({ ...labels, status: result.ok ? 'success':'fail' }).inc();
      return { casinoId:t.casinoId, country:t.country, ok:result.ok, duration:dur, consoleErrors:result.consoleErrors, balancePresent:result.balancePresent, message:result.message };
    } catch (e){
      return { casinoId:t.casinoId, country:t.country, ok:false, duration:0, consoleErrors:0, balancePresent:0, message: e?.message || 'run failed' };
    }
  });

  res.json({ ok:true, results });
});

// scheduler bootstrap (keeps simple)
async function bootstrapScheduler(){
  const schedules = await loadJSON(SCHEDULES_FILE);
  for (const s of schedules){
    const job = new CronJob(s.cron, async () => {
      try {
        await ensureVpn(s.country);
        const { casino, creds } = await getCasinoSpec(s.casinoId);
        const flow = await getFlow(s.flowName);
        const spec = { provider:s.provider, casinoId:s.casinoId, flowName:s.flowName, countryCode:s.country, baseUrl:casino.baseUrl, selectors:casino.selectors||{}, gameUrl:casino.gameUrl||'', flow, creds };
        await runRunner(s.country, spec);
      } catch (e) { console.error('scheduled run failed', e?.message); }
    }, null, true, process.env.TZ || 'UTC');
    job.start();
  }
}
bootstrapScheduler().catch(()=>{});

app.listen(8080, ()=> console.log('API listening on :8080'));
